# JARWIS app
1. Put these files in your GitHub repo: package.json, capacitor.config.json, www/index.html, .github/workflows/build-apk.yml
2. Open the Actions tab and wait for the green check on "build-apk".
3. Open the Releases page, download app-debug.apk, install it (allow "Install unknown apps").
4. In the app: Settings, paste your Gemini key. Turn on Private mode if nothing should leave the phone.
